RAB BENGKEL LAS — PROYEK ANDROID

PENTING:
Ini adalah proyek sumber Android Studio, bukan file APK yang sudah jadi.
Untuk pengguna HP saja, proyek ini menyertakan GitHub Actions untuk membangun APK di cloud.

CARA BUILD DARI HP (memerlukan akun GitHub dan internet):
1. Unduh dan ekstrak ZIP proyek di HP menggunakan aplikasi pengelola file yang bisa mengekstrak ZIP.
2. Buat repository baru di GitHub, beri nama misalnya RAB-Bengkel-Las, pilih Private jika ingin privat.
3. Unggah SELURUH ISI folder proyek ke repository dengan struktur folder tetap terjaga. Folder .github juga harus ikut terunggah.
4. Buka tab Actions pada repository, pilih workflow "Build RAB Bengkel Las APK", lalu tekan Run workflow jika belum berjalan otomatis.
5. Tunggu workflow selesai dengan status hijau.
6. Buka hasil run, gulir ke bagian Artifacts, lalu unduh "RAB-Bengkel-Las-debug-APK".
7. Ekstrak file artifact ZIP yang diunduh. Di dalamnya ada app-debug.apk.
8. Buka APK di HP untuk memasang. Android mungkin meminta izin "Install unknown apps" untuk browser/file manager yang digunakan; aktifkan hanya jika kamu mempercayai file yang dibuat dari repository milikmu sendiri.

CATATAN:
- APK debug ini untuk penggunaan pribadi/pengujian, bukan rilis Play Store.
- Jangan membagikan repository publik jika kode/data atau informasi pribadi dimasukkan.
- Data proyek tersimpan lokal pada data aplikasi. Buat backup sebelum menghapus data atau mencopot pemasangan.
- Ekspor backup berbasis Blob dan pemulihan file perlu diuji di WebView perangkat.
- Kalkulator potongan masih estimasi sederhana, bukan optimasi pola potong profesional.
- Periksa semua hitungan dan harga sebelum memberikan penawaran kepada pelanggan.
